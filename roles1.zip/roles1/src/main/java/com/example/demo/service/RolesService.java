package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.model.Roles;
import com.example.demo.repository.Rolerepo;


@Service
public class RolesService {
@Autowired
Rolerepo repo;
	
public List<Roles> getallroles() {
    List<Roles> list = repo.findAll();
	return list;
}
public Roles saverole(Roles roles) {
	
	return repo.save(roles);
}
/*public ResponseEntity<HttpStatus> deleterole(int id) {
	try {
		repo.deleteById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
}
*/
public void deleterole(long roleid) {
repo.deleteById(roleid);

}
}
