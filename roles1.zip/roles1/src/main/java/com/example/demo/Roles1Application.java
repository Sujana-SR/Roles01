package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Roles1Application {

	public static void main(String[] args) {
		SpringApplication.run(Roles1Application.class, args);
	}

	
	
}
