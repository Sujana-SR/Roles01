package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Appaccess {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
int id;

	@Column
	int roleid;
	@Column
	int appid;
	@Override
	public String toString() {
		return "Appaccess [roleid=" + roleid + ", appid=" + appid + "]";
	}
	public int getRoleid() {
		return roleid;
	}
	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}
	public int getAppid() {
		return appid;
	}
	public void setAppid(int appid) {
		this.appid = appid;
	}
	
	public int getid() {
		return id;
	}
	public void setid(int id) {
		this.id = id;
	}
	
}
