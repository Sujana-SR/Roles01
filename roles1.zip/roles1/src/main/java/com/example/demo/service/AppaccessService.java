package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Admins;

import com.example.demo.model.Applications;
//import com.example.demo.repository.Adminrepo;
import com.example.demo.repository.Appaccessrepo;

@Service
public class AppaccessService {
	@Autowired
	Appaccessrepo repo;

	public List<Applications> getallapplications() {
	    List<Applications> list = repo.findAll();
		return list;
	}

	public Applications saveapplications(Applications applications) {
		
		return repo.save(applications);

	}
}
