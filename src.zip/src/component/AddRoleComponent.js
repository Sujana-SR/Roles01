import React, { useState } from 'react'
import {useHistory} from 'react-router-dom';
import Roleservice from '../service/Roleservice'
import { Link } from 'react-router-dom';


const AddRoleComponent = () => {

const [role, setRole] = useState('')
const [description, setDescription] = useState('')
const history = useHistory();

const saveRole = (e) => {
  e.preventDefault();

const Role = {role, description}
console.log(Role);

Roleservice.createRole(Role).then((response) =>{

  console.log(response.data)

  history.push('/addroles', Role);

}).catch(error => {
  console.log(error)
})

}
  return (
    <div>
      <br /><br />
        <div className='container'>
          <div className='row'>
            <div className='card col-md-7 offset-md-3 offset-md-3'>
              <h2 className='text-center'>Add Role</h2>
              <div className='card-body'>
                <form>
                  <div className='form-group mb-2'>
                    <label className='form-label'>User Role : </label>
                    <input
                    type = "text"
                    placeholder='Enter user role'
                    name='role'
                    className='form-control'
                    value={role}
                    onChange = {(e) => setRole(e.target.value)}
                    >
                    </input>
                  </div>

                  <div className='form-group mb-2'>
                    <label className='form-label'>Description : </label>
                    <input
                    type = "text"
                    placeholder='Enter Description'
                    name='description'
                    className='form-control'
                    value={description}
                    onChange = {(e) => setDescription(e.target.value)}
                    >
                    </input>
                  </div>
                  <button className = "btn btn-success" onClick = {(e) => saveRole(e)} >Submit</button>
                  <Link to="/roles" className="btn bth-danger"> Cancel </Link>
                </form>
              </div>
            </div>
          </div>
        </div>
    </div>
  )
}

export default AddRoleComponent