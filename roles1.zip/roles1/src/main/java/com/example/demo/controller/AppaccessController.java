package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.model.Applications;
import com.example.demo.model.Roles;
import com.example.demo.service.AppaccessService;

@RestController
@RequestMapping
@CrossOrigin(origins = {"http://localhost:3000"})
public class AppaccessController {
	@Autowired
	AppaccessService service;
	@GetMapping("/apps")
	public List<Applications>  getApplications()
	{
		List<Applications> list=service.getallapplications();
	return list;
	}
	
	
	@PostMapping("/addapps")
	public Applications addapplications(@RequestBody Applications applications) {
		applications=service.saveapplications(applications);
		return applications;
	}

}
