package com.example.demo.dto;

import java.util.Date;

public class UserDto {
String fname;
String lname;
Date lastseen;

public UserDto(String fname, String lname, Date lastseen) {
	this.fname = fname;
	this.lname = lname;
	this.lastseen = lastseen;
	
}
}
