package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Admins {
	
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
int id;

	@Column
    String adminname;
	@Column
	String lastseen;
	
	public Admins() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	@Override
	public String toString() {
		return "Admins [id=" + id + ", adminname=" + adminname + ", lastseen=" + lastseen + "]";
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAdminname() {
		return adminname;
	}
	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}
	public String getLastseen() {
		return lastseen;
	}
	public void setLastseen(String lastseen) {
		this.lastseen = lastseen;
	}
	public Admins(int id, String adminname, String lastseen) {
		super();
		this.id = id;
		this.adminname = adminname;
		this.lastseen = lastseen;
	}
}