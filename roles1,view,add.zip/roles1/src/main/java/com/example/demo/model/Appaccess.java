package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Appaccess {
@Id
	@Column
	int roleid;
	@Column
	int appid;
	@Override
	public String toString() {
		return "Appaccess [roleid=" + roleid + ", appid=" + appid + "]";
	}
	public int getRoleid() {
		return roleid;
	}
	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}
	public int getAppid() {
		return appid;
	}
	public void setAppid(int appid) {
		this.appid = appid;
	}
	
	
}
