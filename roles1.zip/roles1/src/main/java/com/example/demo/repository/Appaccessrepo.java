package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//import com.example.demo.model.Appaccess;
import com.example.demo.model.Applications;



@Repository
public interface Appaccessrepo extends JpaRepository<Applications, Integer>{

}
