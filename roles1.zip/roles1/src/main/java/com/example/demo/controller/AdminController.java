package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.Provider.Service;
import java.util.List;

import com.example.demo.dto.UserDto;
import com.example.demo.model.Admins;
import com.example.demo.model.Roles;
import com.example.demo.service.AdminService;
import com.example.demo.service.RolesService;

@RestController
@RequestMapping
@CrossOrigin(origins = {"http://localhost:3000"})
public class AdminController {
@Autowired
	AdminService service;

@GetMapping("/admin")
public List<Admins>  getAdmins()
{
	List<Admins> list=service.getalladmins();
return list;
}

@PostMapping("/addadmins")
public Admins addadmins(@RequestBody Admins  admins) {
	  
	   admins=service.saveadmin(admins);
	   
	return admins;
	   
   }
}


