package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

import javax.persistence.Tuple;
import com.example.demo.model.Admins;

@Repository
public interface Adminrepo extends JpaRepository<Admins, Integer> {


		
}
