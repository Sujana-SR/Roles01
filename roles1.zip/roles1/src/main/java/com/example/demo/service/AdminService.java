package com.example.demo.service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Tuple;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


import com.example.demo.model.Admins;
import com.example.demo.model.Roles;
import com.example.demo.repository.Adminrepo;



import com.example.demo.dto.*;
@Service
public class AdminService {
@Autowired
Adminrepo repo;

public List<Admins> getalladmins() {
    List<Admins> list = repo.findAll();
	return list;
}

public Admins saveadmin(Admins admin) {
	
	return repo.save(admin);

}
}
