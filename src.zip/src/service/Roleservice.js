import axios from 'axios';

const url1 = "http://localhost:8080/roles";
const url2 = "http://localhost:8080/roles/addroles";

 class RolesService{

     getRoles(){

         return axios.get(url1)

     }

     createRole(Role){
         return axios.post(url2, Role)
     }

 }

 export default new RolesService();